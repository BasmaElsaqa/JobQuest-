package com.android.jobquest

class AccountFactory {

    fun createAccount(accountType:String):String
    {
        return "Test"
    }

}